You'll have to code the solution of the individual Tasks in separate Task java files. In each of the Task Java file you'll see two methods; one main method and another method where you'll have to do your coding. Complete each of the tasks inside each java files.

INSTRUCTIONS:
1) Start coding the inside the individual Task java files.
2) Compile and Run each of the Task java files to Test your code.

NOTE:
1) DO NOT MODIFY THE Node.java and LinkedList.java FILE!!!
2) DO NOT MODIFY THE MAIN METHODS OF ANY OF THE TASK java FILES!!!
3) THERE WILL BE 50% PENALTY IF ANY OF THE TWO INSTRUCTIONS ABOVE ISN'T FOLLOWED!!
4) If you find any issues with the Tester Codes please inform AIB.

**Try to use any modern IDEs like VSCode/Netbeans/IntelliJ**
