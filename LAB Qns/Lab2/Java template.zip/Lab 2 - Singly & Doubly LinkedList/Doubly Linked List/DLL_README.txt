INSTRUCTIONS:
1. First of all complete the Patient.java file which will act as our Doubly Node.
2. Then you can write the code of the individual methods inside of the WRM.java file. WRM.java file is a Design class so the main method there won't be there.
3. Lastly, you can write your main method inside of WRMTester.java file where you'll create a WRM object and call all the methods of WRM class to test them. 

NOTE:
1) DO NOT create any new JAVA Files!
2) If you find any issues with the Tester Codes please inform AIB.

**Try to use any modern IDEs like VSCode/Netbeans/IntelliJ**
