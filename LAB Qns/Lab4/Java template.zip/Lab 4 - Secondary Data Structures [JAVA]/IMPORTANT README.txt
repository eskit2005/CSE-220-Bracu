Why don't you guys read the comments??
 __________________
< srsly dude, why? >
 ------------------
        \   ^__^
         \  (oo)\_______
            (__)\       )\/\
                ||----w |
                ||     ||

READ THE COMMENTS!!!!!!!!!!!!!!!!!