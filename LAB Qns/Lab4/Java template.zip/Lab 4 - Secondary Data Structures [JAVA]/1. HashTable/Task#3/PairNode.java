public class PairNode {
    
    Integer key;
    String value;
    PairNode next;

    public PairNode( Integer k, String v ){
        // TO DO
    }
    
}
