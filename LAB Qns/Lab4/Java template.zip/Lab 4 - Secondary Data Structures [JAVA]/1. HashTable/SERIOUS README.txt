Since there are duplicate class names,
keep the tasks of HashTable in separate folders!

You you can RUN the Tester classes from inside of each folder.